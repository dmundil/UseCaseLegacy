using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace IPAChallengeDesktop
{
    public partial class MainForm : Form
    {
        // Einfache Mock Datenbank für den Use Case
        private class Employee
        {
            public string FirstName;
            public string LastName;
            public bool Exists;
        }

        private List<Employee> mockData = new List<Employee>
        {
            new Employee { FirstName = "Anna", LastName = "Schmidt", Exists = true },
            new Employee { FirstName = "Max", LastName = "Mustermann", Exists = false },
            new Employee { FirstName = "Julia", LastName = "Weber", Exists = true }
        };

        private Panel searchPanel;
        private Panel formPanel;
        private Label statusLabel;
        private Random rng = new Random();

        public MainForm()
        {
            this.Text = "IPA Challenge Pro Max (Desktop)";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeUI();
        }

        private void InitializeUI()
        {
            // Status Anzeige oben
            statusLabel = new Label { Dock = DockStyle.Top, Height = 40, TextAlign = ContentAlignment.MiddleCenter, Font = new Font("Segoe UI", 12, FontStyle.Bold), Text = "Bereit. Bitte Mitarbeiter suchen." };
            this.Controls.Add(statusLabel);

            // 1. Suchbereich
            searchPanel = new Panel { Dock = DockStyle.Top, Height = 100, BackColor = Color.WhiteSmoke, Padding = new Padding(20) };
            var lblSearch = new Label { Text = "Nachname suchen:", Location = new Point(20, 30), AutoSize = true };
            var txtSearch = new TextBox { Location = new Point(150, 27), Width = 200 };
            var btnSearch = new Button { Text = "Suchen", Location = new Point(360, 25), Width = 100, BackColor = Color.LightSteelBlue };

            btnSearch.Click += (s, e) => PerformSearch(txtSearch.Text);

            searchPanel.Controls.Add(lblSearch);
            searchPanel.Controls.Add(txtSearch);
            searchPanel.Controls.Add(btnSearch);
            this.Controls.Add(searchPanel);

            // 2. Dynamischer Formularbereich
            formPanel = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Color.White };
            this.Controls.Add(formPanel);
            formPanel.BringToFront();
        }

        private void PerformSearch(string query)
        {
            var emp = mockData.FirstOrDefault(x => x.LastName.Equals(query, StringComparison.OrdinalIgnoreCase));
            
            formPanel.Controls.Clear();
            
            if (emp != null)
            {
                statusLabel.Text = emp.Exists ? "Mitarbeiter gefunden: ENTFERNEN" : "Mitarbeiter unbekannt: HINZUFÜGEN";
                GenerateDynamicForm(emp.Exists);
            }
            else
            {
                statusLabel.Text = "Niemand gefunden. Versuchen Sie 'Schmidt' oder 'Weber'.";
            }
        }

        // Kernlogik: Generiert das Formular jedes Mal neu (Chaos Faktor)
        private void GenerateDynamicForm(bool isDeleteMode)
        {
            int yPos = 20;
            var fields = new List<string> { "Vorname", "Nachname", "Job Titel", "Email" };
            
            // Zufällige Reihenfolge der Felder
            fields = fields.OrderBy(x => rng.Next()).ToList();

            foreach (var field in fields)
            {
                CreateStandardField(field, ref yPos);
            }

            // Das polymorphe 'Grund' Feld (Pro Max Anforderung)
            CreatePolymorphicReasonField(ref yPos);

            var btnSubmit = new Button { Text = isDeleteMode ? "Entfernen" : "Speichern", Location = new Point(50, yPos + 30), Width = 150, Height = 40, BackColor = isDeleteMode ? Color.LightCoral : Color.LightGreen };
            btnSubmit.Click += (s, e) => { MessageBox.Show("Erfolg! Nächster Durchlauf."); formPanel.Controls.Clear(); statusLabel.Text = "Bereit."; };
            formPanel.Controls.Add(btnSubmit);
        }

        private void CreateStandardField(string labelText, ref int y)
        {
            // Zufällige Positionierung (X-Achse variiert leicht)
            int xOffset = rng.Next(0, 50); 
            
            var lbl = new Label { Text = labelText, Location = new Point(50 + xOffset, y), AutoSize = true };
            var txt = new TextBox { Location = new Point(200 + xOffset, y), Width = 200 }; // Name dynamisch vergeben wäre noch schwerer
            
            formPanel.Controls.Add(lbl);
            formPanel.Controls.Add(txt);
            y += 50;
        }

        private void CreatePolymorphicReasonField(ref int y)
        {
            int type = rng.Next(3); // 0 = Combo, 1 = Radio, 2 = Text
            int xOffset = rng.Next(0, 50);

            var lbl = new Label { Text = "Grund (Reason)", Location = new Point(50 + xOffset, y), AutoSize = true, Font = new Font(this.Font, FontStyle.Bold) };
            formPanel.Controls.Add(lbl);

            Control inputControl = null;

            if (type == 0) // ComboBox
            {
                var combo = new ComboBox { Location = new Point(200 + xOffset, y), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
                combo.Items.AddRange(new object[] { "Urlaub", "Krankheit", "Kündigung" });
                inputControl = combo;
            }
            else if (type == 1) // Radio Buttons
            {
                var panel = new FlowLayoutPanel { Location = new Point(200 + xOffset, y), Width = 300, Height = 30 };
                panel.Controls.Add(new RadioButton { Text = "Urlaub", AutoSize = true });
                panel.Controls.Add(new RadioButton { Text = "Krankheit", AutoSize = true });
                inputControl = panel;
            }
            else // Simple TextBox
            {
                inputControl = new TextBox { Location = new Point(200 + xOffset, y), Width = 200 };
            }

            formPanel.Controls.Add(inputControl);
            y += 60;
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new MainForm());
        }
    }
}